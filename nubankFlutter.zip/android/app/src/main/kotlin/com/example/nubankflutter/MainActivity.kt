package com.example.nubankflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
